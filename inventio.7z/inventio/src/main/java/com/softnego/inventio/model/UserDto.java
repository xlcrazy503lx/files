package com.softnego.inventio.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDto {
    private String username;
    private String password;
    private int age;
    private int salary;
}
