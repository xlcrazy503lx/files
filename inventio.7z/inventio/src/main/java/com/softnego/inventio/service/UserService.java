package com.softnego.inventio.service;

import com.softnego.inventio.model.entity.User;
import com.softnego.inventio.model.UserDto;

import java.util.List;

public interface UserService {
    User save(UserDto user);
    List<User> findAll();
    void delete(long id);
    User findOne(String username);
    User findById(Long id);
}
