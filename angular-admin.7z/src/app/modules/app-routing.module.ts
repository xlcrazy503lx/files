import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {SidenavComponent} from '../components/sidenav/sidenav/sidenav.component';
import {LoginComponent} from '../components/login/login.component';
import {AppComponent} from '../app.component';
import {HomeComponent} from '../components/home/home.component';
import {NotfoundComponent} from '../components/notfound/notfound.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent ,
  },
  {
    path: 'home',
    component: HomeComponent ,
  },
  {
    path: 'dashboard',
    component: SidenavComponent,
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: '404', component: NotfoundComponent
  },
  {
   path: '**', redirectTo: '/404'
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
