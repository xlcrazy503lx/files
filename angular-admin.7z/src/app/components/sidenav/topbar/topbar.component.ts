import { Component, OnInit } from '@angular/core';
import {EventemitterService} from '../../../services/eventemitter/eventemitter.service';

@Component({
  selector: 'app-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.css']
})
export class TopbarComponent implements OnInit {
  public tittleComponent:string = 'Dashboard';
  constructor(private eventEmitterService: EventemitterService) { }

  ngOnInit(): void {
  }
  firstComponentFunction(){
    this.eventEmitterService.onFirstComponentButtonClick();
  }

}
