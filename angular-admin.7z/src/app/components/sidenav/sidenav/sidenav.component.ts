import {Component, OnInit} from '@angular/core';
import {EventemitterService} from '../../../services/eventemitter/eventemitter.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent implements OnInit {
  public toggled: boolean = false; // using double quotes
  public username: string = 'ADMIN1';
  constructor(private eventEmitterService: EventemitterService) { }
  changeToggled():void{
    this.toggled=!this.toggled;
  }
  ngOnInit() {
    if (this.eventEmitterService.subsVar == undefined) {
      this.eventEmitterService.subsVar = this.eventEmitterService.
      invokeFirstComponentFunction.subscribe((name:string) => {
        this.changeToggled();
      });
    }
  }
}
