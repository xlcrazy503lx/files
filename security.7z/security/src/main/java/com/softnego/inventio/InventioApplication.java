package com.softnego.inventio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventioApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventioApplication.class, args);
	}

}
