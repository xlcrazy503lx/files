package com.softnego.inventio.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Entity
@Getter
@Setter
public class User {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;
    @Column(unique = true)
    private String username;
    @Column
    @JsonIgnore
    private String password;
    @Column
    private long salary;
    @Column
    private int age;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "USER_ROLES",
            joinColumns = {
                @JoinColumn(name = "USER_ID") }, inverseJoinColumns = {
                @JoinColumn(name = "ROLE_ID")},
            uniqueConstraints = {@UniqueConstraint(columnNames = {"USER_ID","ROLE_ID"})})
    private List<Role> roles;

    public void addRole(Role role){
        if (roles==null){
            roles = new ArrayList<>();
        }
        this.roles.add(role);
    }

}
