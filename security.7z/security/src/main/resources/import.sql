INSERT INTO user (id, username, password, salary, age) VALUES (1, 'user1', '$2y$12$ctIE/E/5xSFM0EAED8jYl.DRQHtG730sIWljGjjvoDOLNYenCr2eS', 3456, 33);
INSERT INTO user (id, username, password, salary, age) VALUES (2, 'user2', '$2y$12$ctIE/E/5xSFM0EAED8jYl.DRQHtG730sIWljGjjvoDOLNYenCr2eS', 7823, 23);
INSERT INTO user (id, username, password, salary, age) VALUES (3, 'user3', '$2y$12$ctIE/E/5xSFM0EAED8jYl.DRQHtG730sIWljGjjvoDOLNYenCr2eS', 4234, 45);

INSERT INTO role (id, description, name) VALUES (4, 'Admin role', 'ADMIN');
INSERT INTO role (id, description, name) VALUES (5, 'User role', 'USER');

INSERT INTO user_roles (user_id, role_id) VALUES (1, 4);
INSERT INTO user_roles (user_id, role_id) VALUES (1, 5);
INSERT INTO user_roles (user_id, role_id) VALUES (2, 5);