package com.softnego.inventio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventioApplicationTests {

	@Test
	void contextLoads() {
	}

}
